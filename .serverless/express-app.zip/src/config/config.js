module.exports = {
  // db: "mongodb://root:root123@ds251799.mlab.com:51799/node-api-digi",
  db: "mongodb://root:root123@ds251799.mlab.com:51799/node-api-digi",
  secret: "node-api-secret",
  refreshTokenSecret: "node-api-refresh-token",
  port: 3000,
  tokenLife: 9000,
};
